# PauseAm model services

Build from this archive root:

    docker build -f asr/Dockerfile .
    docker build -f text_service/Dockerfile .

The recommended pilot uses actual digest-pinned images recorded in the public repository at submission/evidence/model-container-build-2026-10-02.json. Configure secrets privately, share one LICENSE_DB volume across all services, and verify real inference before enabling the app. No weights, API token, participant record or inference evidence is bundled. See submission/04-technical/model-hosting.md.
